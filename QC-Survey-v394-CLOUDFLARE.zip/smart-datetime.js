/* QC Survey v333 — mobile-safe native date/time controls; no recursive synthetic clicks. */
(function(){'use strict';var timer=0;
function ar(){try{return window.QCI18N&&QCI18N.getLanguage()==='ar'}catch(e){return document.documentElement.dir==='rtl'}}
function T(en,aa){return ar()?aa:en}
function localDate(){var d=new Date(),y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');return y+'-'+m+'-'+day}
function localTime(){var d=new Date();return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')}
/* Programmatic callers may request the native picker. Never call el.click() here:
   on Android it re-enters the input click handler and can freeze the page. */
function openPicker(el){if(!el||el.disabled||el.readOnly)return false;try{el.focus({preventScroll:true})}catch(e){try{el.focus()}catch(x){}}try{if(typeof el.showPicker==='function'){el.showPicker();return true}}catch(e2){}return false}
function enhance(el){if(!el)return;var type=el.type;if(type!=='date'&&type!=='time'&&type!=='datetime-local')return;el.dataset.qdtEnhanced='1';el.classList.add('qdt-enhanced');if(type==='time')el.step='60';el.title=type==='date'?T('Choose a date from the native calendar','اختر التاريخ من التقويم'):type==='time'?T('Choose time from the native clock or type HH:MM','اختر الوقت من الساعة أو اكتب HH:MM'):T('Choose date and time','اختر التاريخ والوقت');/* Native date/time inputs already open themselves on a trusted tap. No click listener is added. */}
function scan(){document.querySelectorAll('.qdt-tools').forEach(function(x){x.remove()});document.querySelectorAll('input[type="date"],input[type="time"],input[type="datetime-local"]').forEach(enhance)}
function relabel(){document.querySelectorAll('input.qdt-enhanced').forEach(enhance)}
function boot(){scan();if(window.MutationObserver)new MutationObserver(function(){clearTimeout(timer);timer=setTimeout(scan,80)}).observe(document.body,{childList:true,subtree:true});window.addEventListener('qc:language',relabel);window.__qcSmartDateTime={scan:scan,today:localDate,now:localTime,open:openPicker}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
