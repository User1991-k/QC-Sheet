/* QC Survey v349 — calm sand reading theme with light, dim and dark modes. */
(function(){'use strict';
var D=document,KEY='qc_comfort_theme_v349',MODES=['light','dim','dark'];
function ar(){return D.documentElement.dir==='rtl'}function T(e,a){return ar()?a:e}function load(){try{var x=JSON.parse(localStorage.getItem(KEY)||'{}');return MODES.indexOf(x.mode)>=0?x:{mode:'light'}}catch(e){return{mode:'light'}}}function save(x){try{localStorage.setItem(KEY,JSON.stringify(x))}catch(e){}}
function meta(mode){return mode==='dark'?{icon:'☾',en:'Dark',ar:'داكن'}:mode==='dim'?{icon:'◐',en:'Dim',ar:'خافت'}:{icon:'☀',en:'Light',ar:'فاتح'}}
function apply(mode,quiet){if(MODES.indexOf(mode)<0)mode='light';MODES.forEach(function(x){D.documentElement.classList.toggle('qc-comfort-'+x,x===mode)});D.documentElement.classList.add('qc-comfort');D.documentElement.dataset.qcComfort=mode;var b=D.getElementById('qc-comfort-toggle'),m=meta(mode);if(b){b.innerHTML='<span>'+m.icon+'</span><b>'+T(m.en,m.ar)+'</b>';b.title=T('Reading mode: ','وضع القراءة: ')+T(m.en,m.ar);b.setAttribute('aria-label',b.title)}var theme=document.querySelector('meta[name="theme-color"]');if(theme)theme.content=mode==='dark'?'#252a26':mode==='dim'?'#d8d0c2':'#f4f0e7';save({mode:mode});if(!quiet&&window.toast)toast(T('Reading mode: ','وضع القراءة: ')+T(m.en,m.ar),'ok');D.dispatchEvent(new CustomEvent('qc:comfort-theme',{detail:{mode:mode}}))}
function cycle(){var x=load(),i=MODES.indexOf(x.mode);apply(MODES[(i+1)%MODES.length])}
function button(){if(D.getElementById('qc-comfort-toggle'))return;var b=D.createElement('button');b.id='qc-comfort-toggle';b.type='button';b.setAttribute('data-qc-i18n-skip','');b.onclick=cycle;var tools=D.getElementById('top-tools'),nav=D.querySelector('.nav-inner');if(tools)tools.insertBefore(b,tools.firstChild);else if(nav)nav.appendChild(b);else D.body.appendChild(b);apply(load().mode,true)}
new MutationObserver(function(){var b=D.getElementById('qc-comfort-toggle'),m=meta(load().mode);if(b){b.innerHTML='<span>'+m.icon+'</span><b>'+T(m.en,m.ar)+'</b>'}}).observe(D.documentElement,{attributes:true,attributeFilter:['dir']});
window.QCComfortTheme={set:function(mode){apply(mode)},get:function(){return load().mode},cycle:cycle,version:'349.0'};
if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',button);else button();
})();
