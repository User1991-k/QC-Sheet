/* QC Survey v379 — one final export station per module. */
(function(){'use strict';
var D=document,busy=false,timer=0;
var MAP={
 ts:'#btn-ts-pdf-bottom',ls:'#btn-ls-pdf-bottom',sc:'#btn-sc-pdf',gnss:'#btn-gnss-pdf',
 flange:'#df-export',gpr:'[data-gpr-action="pdf"]',drone:'[data-pdf]',dpr:'#btn-dpr-pdf',
 backfill:'#btn-backfill-pdf',mm:'[data-mm-pdf]',rd:'[data-rd-pdf]',conv:'[data-qc-page-pdf]'
};
function ar(){return D.documentElement.dir==='rtl'}
function build(view,key){var bar=view.querySelector(':scope > .qc-final-export');if(!bar){bar=D.createElement('section');bar.className='qc-final-export no-print';bar.dataset.module=key;bar.innerHTML='<div><strong></strong><small></small></div><div class="qc-final-export-action"></div>';view.appendChild(bar)}return bar}
function place(key){var view=D.getElementById('view-'+key);if(!view)return;var matches=Array.from(view.querySelectorAll(MAP[key])),btn=matches.find(function(x){return x.dataset.qcBottomExport==='1'})||matches[0];if(!btn)return;matches.forEach(function(x){if(x!==btn)x.remove()});var bar=build(view,key),slot=bar.querySelector('.qc-final-export-action');if(btn.parentNode!==slot)slot.appendChild(btn);if(view.lastElementChild!==bar)view.appendChild(bar);btn.hidden=false;btn.removeAttribute('style');btn.classList.remove('qc-action-menu-item');btn.classList.add('qc-final-export-button');btn.dataset.qcBottomExport='1';var bt=ar()?'تصدير PDF':'Export PDF',st=ar()?'التصدير النهائي':'Final export',nt=ar()?'زر PDF واحد في نهاية هذا القسم. يشمل التقرير جميع التفاصيل والصفوف المحفوظة حتى لو كانت مطوية في الشاشة، وتنتقل كاملة إلى الصفحة التالية.':'One PDF button at the end of this module. The report includes every saved detail and row even when collapsed on screen, moving complete content cleanly to the next page.',sn=bar.querySelector('strong'),nn=bar.querySelector('small');if(btn.textContent!==bt)btn.textContent=bt;if(sn.textContent!==st)sn.textContent=st;if(nn.textContent!==nt)nn.textContent=nt}
function scan(){if(busy)return;busy=true;try{Object.keys(MAP).forEach(place)}finally{busy=false}}
function activeKey(){var v=D.querySelector('main.page:not(.hidden)');return v&&v.id.replace('view-','')}
function queue(){clearTimeout(timer);timer=setTimeout(function(){var k=activeKey();if(k&&MAP[k])place(k)},100)}
if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',function(){setTimeout(scan,120)});else setTimeout(scan,120);
new MutationObserver(function(ms){if(busy)return;var v=D.querySelector('main.page:not(.hidden)');if(v&&ms.some(function(m){return v.contains(m.target)||Array.from(m.addedNodes||[]).some(function(n){return n&&n.nodeType===1&&v.contains(n)})}))queue()}).observe(D.body,{subtree:true,childList:true});
new MutationObserver(scan).observe(D.documentElement,{attributes:true,attributeFilter:['dir']});
D.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-tab],[data-switch-tab]');if(!b)return;var k=b.getAttribute('data-tab')||b.getAttribute('data-switch-tab');[80,k==='flange'?1250:420].forEach(function(delay){setTimeout(function(){if(k&&MAP[k])place(k);else queue()},delay)})},true);
window.QCPdfFlow={scan:scan,version:'379.0'};
})();
