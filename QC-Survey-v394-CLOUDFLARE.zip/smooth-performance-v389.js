/* QC Survey v389 — smooth navigation, progressive startup and safe page suspension. */
(function(){'use strict';
var D=document,KEY='qc_smooth_v389',state={history:[],scroll:{}},booted=false,lastCaptured={key:'',at:0};
try{state=Object.assign(state,JSON.parse(sessionStorage.getItem(KEY)||'{}'))}catch(e){}
function ar(){return D.documentElement.dir==='rtl'}function T(en,a){return ar()?a:en}
function save(){try{sessionStorage.setItem(KEY,JSON.stringify(state))}catch(e){}}
function active(){var t=D.querySelector('.tabs .tab.active[data-tab]');return t&&t.dataset.tab||''}
function remember(k){if(!k)return;state.history=state.history.filter(function(x){return x!==k});state.history.push(k);if(state.history.length>12)state.history.shift();save()}
function previous(){var now=active();for(var i=state.history.length-1;i>=0;i--)if(state.history[i]!==now)return state.history[i];return''}
function go(k){var b=D.querySelector('.tabs .tab[data-tab="'+k+'"]');if(b)b.click()}
function installBack(){var panel=D.querySelector('.qc-page-switcher-panel'),head=panel&&panel.querySelector(':scope>header');if(!head||head.querySelector('[data-qc-previous]'))return;var b=D.createElement('button');b.type='button';b.dataset.qcPrevious='';b.className='qc-previous-page';b.onclick=function(){var k=previous();if(k){go(k);var close=panel.querySelector('[data-switch-close]');if(close)close.click()}};head.insertBefore(b,head.lastElementChild);updateBack()}
function updateBack(){var b=D.querySelector('[data-qc-previous]'),k=previous();if(!b)return;b.hidden=!k;b.textContent='↶ '+T('Previous','السابق');b.title=T('Return to the previous page','العودة إلى الصفحة السابقة')}
function restore(k){var y=Number(state.scroll[k]||0);requestAnimationFrame(function(){setTimeout(function(){scrollTo({top:y,left:0,behavior:'auto'})},240)})}
D.addEventListener('qc:pagesuspend',function(e){var k=e.detail&&e.detail.from;if(k){if(lastCaptured.key===k&&Date.now()-lastCaptured.at<600)return;state.scroll[k]=Math.max(0,Math.round(scrollY));save()}});
D.addEventListener('qc:pageactive',function(e){var k=e.detail&&e.detail.to;if(k){remember(k);restore(k);updateBack()}});
D.addEventListener('click',function(e){var target=e.target.closest('.tab[data-tab],[data-switch-tab]'),now=active();if(target&&now){var dest=target.dataset.tab||target.dataset.switchTab;if(dest&&dest!==now){state.scroll[now]=Math.max(0,Math.round(scrollY));lastCaptured={key:now,at:Date.now()};save()}}if(e.target.closest('.qc-page-switcher-trigger'))setTimeout(installBack,0)},true);
function ready(){if(booted)return;booted=true;D.documentElement.classList.remove('qc-progressive-start');D.documentElement.classList.add('qc-progressive-ready');installBack();remember(active())}
D.documentElement.classList.add('qc-progressive-start');
if('requestIdleCallback'in window)requestIdleCallback(ready,{timeout:1400});else setTimeout(ready,700);
window.addEventListener('load',function(){setTimeout(ready,80)},{once:true});
window.QCSmoothPerformance={previous:function(){var k=previous();if(k)go(k)},status:function(){return{active:active(),previous:previous(),lowResource:!!window.__QC_LOW_RESOURCE,history:state.history.slice()}},version:'389.0'};
})();
